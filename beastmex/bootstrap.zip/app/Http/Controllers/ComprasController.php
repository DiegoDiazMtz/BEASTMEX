<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;//manejo de base de datos
use App\Models\compras;

class comprasController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $consultaProductos = DB::table('productos')->orderBy('cantidad', 'asc')->get()->where('estatus', '=', 1);
        
        return view('compras/compras', compact('consultaProductos'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('compras/agregar');
    }

    public function createOrden()
    {
        return view('compras/agregarOrden');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function filtrar(Request $request)
    {
        $filtro = $request->input('filtro');
        if ($filtro == null) {
            return redirect()->route('compras.index')->with('fallo', 'No se encontró ningún producto con ese nombre o número de serie.');
        }

        $consultaProductos = DB::table('productos')
        ->where('estatus', '=', 1)
        ->where(function ($query) use ($filtro) {
            $query->where('nombre_producto', 'like', '%' . $filtro . '%')
                ->orWhere('no_serie', 'like', '%' . $filtro . '%');
        })
        ->get();


        if ($consultaProductos->isEmpty()) {
            return redirect()->route('compras.index')->with('fallo', 'No se encontró ningún producto con ese nombre o número de serie.');
        }

        return view('compras/compras', compact('consultaProductos'));
    }
}
