<?php $__env->startSection('estilos'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/almacen.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <form method="POST" action="<?php echo e(route('almacen.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <h1 class="titulo">Agregar producto</h1>

        <div class="form-group card">
            <label >Nombre del producto</label>
            <input type="text" class="form-control" name="nombreProd" value="<?php echo e(old('nombreProd')); ?>">
            <strong style="color: red"><?php echo e($errors->has('nombreProd') ? $errors->first('nombreProd') : ''); ?></strong>

            <label >Numero de serie</label>
            <input type="text" class="form-control" name="numeroSerie" value="<?php echo e(old('numeroSerie')); ?>">
            <strong style="color: red"><?php echo e($errors->has('numeroSerie') ? $errors->first('numeroSerie') : ''); ?></strong>
            
            <label >Marca</label>
            <input type="text" class="form-control" name="marca" value="<?php echo e(old('marca')); ?>">
            <strong style="color: red"><?php echo e($errors->has('marca') ? $errors->first('marca') : ''); ?></strong>
            
            <label >Cantidad</label>
            <input type="text" class="form-control" name="cantidad" value="<?php echo e(old('cantidad')); ?>">
            <strong style="color: red"><?php echo e($errors->has('cantidad') ? $errors->first('cantidad') : ''); ?></strong>
            
            <label >Costo compra</label>
            <input type="text" class="form-control" name="costoCompra" value="<?php echo e(old('costoCompra')); ?>">
            <strong style="color: red"><?php echo e($errors->has('costoCompra') ? $errors->first('costoCompra') : ''); ?></strong>
            
            <label >Foto</label>
            <input type="file" class="form-control" name="foto" value="<?php echo e(old('foto')); ?>">
            <strong style="color: red"><?php echo e($errors->has('foto') ? $errors->first('foto') : ''); ?></strong>

            <input type="submit" class="boton btn btn-primary" value="Enviar">
        </div>

    </form>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\patit\OneDrive\Documentos\RepositoriosDelGit\BEASTMEX\beastmex\resources\views/almacen/agregar.blade.php ENDPATH**/ ?>