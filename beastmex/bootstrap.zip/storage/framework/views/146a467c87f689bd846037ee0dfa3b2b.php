<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Productos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        header {
            text-align: center;
            /*  background-color: #333;*/
            color: white;
            padding: 10px;
        }

        header img {
            max-width: 100px; /* Ajusta el ancho según sea necesario */
            height: auto;
            margin-right: 10px;
        }

        h1 {
            text-align: center;
            color: #333;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

    <header>
        <h1>BeastMex - Lista de Productos</h1>
        <hr style="border-top: 2px solid white;">
    </header>

    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Marca</th>
                <th>Precio</th>
                <th>Stock</th>
                <th>Fecha de Registro</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $consultaProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($producto->nombre_producto); ?></td>
                    <td><?php echo e($producto->marca); ?></td>
                    <td>$<?php echo e($producto->precio_venta); ?></td>
                    <td><?php echo e($producto->cantidad); ?></td>
                    <td><?php echo e($producto->fecha_ingreso); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH C:\Users\patit\OneDrive\Documentos\RepositoriosDelGit\BEASTMEX\beastmex\resources\views/pdf/lista_productos.blade.php ENDPATH**/ ?>