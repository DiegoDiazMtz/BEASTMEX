<?php $__env->startSection('estilos'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/consulta.css')); ?>">
<script src="https://unpkg.com/sweetalert2@9.5.3/dist/sweetalert2.all.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <?php if(session()->has('fallo')): ?>
    <script>
        const confirmacion = <?php echo json_encode(session('fallo'), 15, 512) ?>;
        Swal.fire({
            icon: 'error',
            title: confirmacion,
        });
    </script>
    <?php echo e(session()->forget('fallo')); ?>

    <?php endif; ?>

    <h1 class="titulo">Compras</h1>
    <div class="consultar"> 
        <h3 class="subtitulo"> Consultar productos disponibles</h3>
    </div>  

    <div class="buscar-imprimir">
        <div class="col-sm-8 me-3">
            <form class="d-flex" action="<?php echo e(route('compras.filtrar')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input class="form-control me-2" name="filtro" placeholder="Productos disponibles" aria-label="Search">
                <button class="btn btn-outline-secondary me-2" type="submit"">Buscar</button>
            </form>
        </div>
        <div class="col-sm-4 d-grid gap-2">
            <div class="d-flex">
                <a href="<?php echo e(route('compras.createOrden')); ?>" class="btn btn-primary">Generar Orden de Compra</a>
                <a href="<?php echo e(route('compras.create')); ?>" class="btn btn-primary boton-especial"> Consultar todas las compras</a>
            </div>
        </div>
    </div>
    
    <div class="tarjetas mt-5">
        <?php $__currentLoopData = $consultaProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($producto->cantidad < 2): ?>
                <div class="card menosde2">
            <?php else: ?>
                <div class="card">  
            <?php endif; ?>
                <div class="card-img-top align-content-center" style="height: 250px; overflow: hidden;">
                    <img src="<?php echo e(asset($producto->foto)); ?>" alt="imagen-del-producto" style="object-fit: cover; max-height: 100%;">
                </div>
                
                <div class="card-body">
                    <h5 class="card-title bold"><strong><?php echo e($producto->nombre_producto); ?></strong></h5>
                    <div class="row mb-4">
                        <div class="col-sm-12 marca">
                            <strong>Marca: </strong><?php echo e($producto->marca); ?>

                        </div>
                        <div class="col-sm-6 marca card-text">
                            <strong>Precio: </strong><?php echo e($producto->precio_venta); ?>

                        </div>
                        <div class="col-sm-6 marca card-text">
                            <?php if($producto->cantidad < 2): ?>
                                <strong class="resaltado">Stock: <?php echo e($producto->cantidad); ?></strong>
                            <?php else: ?>
                                <strong>Stock: </strong><?php echo e($producto->cantidad); ?>

                            <?php endif; ?>
                        </div>
                        <div class="col-sm-12 marca card-text">
                            <strong>Numero de serie: </strong><?php echo e($producto->no_serie); ?>

                        </div>
                        <div class="col-sm-12 marca card-text">
                            <strong>Fecha de registro: </strong><?php echo e($producto->fecha_ingreso); ?>

                        </div>
                    </div>
                </div>
            </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\patit\OneDrive\Documentos\RepositoriosDelGit\BEASTMEX\beastmex\resources\views/compras/compras.blade.php ENDPATH**/ ?>