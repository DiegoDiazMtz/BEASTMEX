<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/login.css">
    <script src="https://unpkg.com/sweetalert2@9.5.3/dist/sweetalert2.all.min.js"></script>
</head>
<body>
    <?php if(session()->has('fail')): ?>
    <script>
        const confirmacion = <?php echo json_encode(session('fail'), 15, 512) ?>;
        Swal.fire({
            icon: 'error',
            title: confirmacion,
        });
    </script>
    <?php echo e(session()->forget('fail')); ?>

    <?php endif; ?>
    <div class="container">
        <div class="row"> 
            <div class="col-md-6"> 
                <div class="card"> 
                    <form method="POST" class="box" action="<?php echo e(route('login.login')); ?>"> 
                        <?php echo csrf_field(); ?>
                        <h1 titulo-login>Inicio de Sesión</h1> 
                        <p class="text-muted"> Ingrese su correo y su contraseña</p> 
                        <input type="text" name="correo" placeholder="<?php echo e($errors->has('correo') ? $errors->first('correo') : 'Correo'); ?>"> 
                        <input type="password" name="contrasena" placeholder="<?php echo e($errors->has('contrasena') ? $errors->first('contrasena') : 'Contraseña'); ?>"> 
                        <a class="forgot text-muted" href="/cambiarContraseña">¿Olvidaste la contraseña?</a> 
                        <input type="submit" value="Ingresar"> 
                    </form> 
                </div> 
            </div> 
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\patit\OneDrive\Documentos\RepositoriosDelGit\BEASTMEX\beastmex\resources\views/login.blade.php ENDPATH**/ ?>