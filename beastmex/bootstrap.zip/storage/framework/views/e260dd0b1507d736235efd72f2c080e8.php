<?php $__env->startSection('estilos'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/administrador.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <h1 class="titulo">Administrador</h1>

    <div class="row graficas">
        <?php for($i = 1; $i <= 4; $i++): ?>
            <div class="col-md-6 grafica">
                <canvas id="myChart<?php echo e($i); ?>"></canvas>
            </div>
        <?php endfor; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        <?php for($i = 1; $i <= 2; $i++): ?>
            var ctx<?php echo e($i); ?> = document.getElementById('myChart<?php echo e($i); ?>').getContext('2d');
            var myChart<?php echo e($i); ?> = new Chart(ctx<?php echo e($i); ?>, {
                type: 'bar',  // Cambia el tipo de gráfico según tus necesidades
                data: {
                    labels: <?php echo json_encode($data->pluck('nombre_producto'), 15, 512) ?>,
                    datasets: [
                        {
                        label: 'Cantidad en stock',
                        data: <?php echo json_encode($data->pluck('cantidad'), 15, 512) ?>,
                        
                        backgroundColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(255, 255, 0, 1)',
                            'rgba(0, 255, 0, 1)',
                            'rgba(0, 0, 255, 1)',
                            'rgba(255, 0, 255, 1)',
                            'rgba(128, 128, 128, 1)',
                            'rgba(255, 165, 0, 1)',
                            'rgba(0, 128, 128, 1)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(255, 255, 0, 1)',
                            'rgba(0, 255, 0, 1)',
                            'rgba(0, 0, 255, 1)',
                            'rgba(255, 0, 255, 1)',
                            'rgba(128, 128, 128, 1)',
                            'rgba(255, 165, 0, 1)',
                            'rgba(0, 128, 128, 1)'
                        ],
                        borderWidth: 1
                        },
                        {
                        type: 'line',
                        label: 'Cantidad en stock',
                        data: <?php echo json_encode($data->pluck('cantidad'), 15, 512) ?>,
                        
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.4)',
                            'rgba(255, 255, 0, 0.4)',
                            'rgba(0, 255, 0, 0.4)',
                            'rgba(0, 0, 255, 0.4)',
                            'rgba(255, 0, 255, 0.4)',
                            'rgba(128, 128, 128, 0.4)',
                            'rgba(255, 165, 0, 0.4)',
                            'rgba(0, 128, 128, 0.4)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(255, 255, 0, 1)',
                            'rgba(0, 255, 0, 1)',
                            'rgba(0, 0, 255, 1)',
                            'rgba(255, 0, 255, 1)',
                            'rgba(128, 128, 128, 1)',
                            'rgba(255, 165, 0, 1)',
                            'rgba(0, 128, 128, 1)'
                        ],
                        borderWidth: 1
                        },
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    indexAxis: 'y',
                    scales: {
                        x: {
                            stacked: true,
                        },
                        y: {
                            stacked: true
                        }
                    }
                }
            });
        <?php endfor; ?>
        <?php for($i = 3; $i <= 4; $i++): ?>
            var ctx<?php echo e($i); ?> = document.getElementById('myChart<?php echo e($i); ?>').getContext('2d');
            var myChart<?php echo e($i); ?> = new Chart(ctx<?php echo e($i); ?>, {
                type: 'bar',  // Cambia el tipo de gráfico según tus necesidades
                data: {
                    labels: <?php echo json_encode($data->pluck('nombre_producto'), 15, 512) ?>,
                    datasets: [
                        {
                        label: 'Cantidad en stock',
                        data: <?php echo json_encode($data->pluck('cantidad'), 15, 512) ?>,
                        
                        backgroundColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(255, 255, 0, 1)',
                            'rgba(0, 255, 0, 1)',
                            'rgba(0, 0, 255, 1)',
                            'rgba(255, 0, 255, 1)',
                            'rgba(128, 128, 128, 1)',
                            'rgba(255, 165, 0, 1)',
                            'rgba(0, 128, 128, 1)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(255, 255, 0, 1)',
                            'rgba(0, 255, 0, 1)',
                            'rgba(0, 0, 255, 1)',
                            'rgba(255, 0, 255, 1)',
                            'rgba(128, 128, 128, 1)',
                            'rgba(255, 165, 0, 1)',
                            'rgba(0, 128, 128, 1)'
                        ],
                        borderWidth: 1
                        },
                        {
                        type: 'line',
                        label: 'Cantidad en stock',
                        data: <?php echo json_encode($data->pluck('cantidad'), 15, 512) ?>,
                        
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.4)',
                            'rgba(255, 255, 0, 0.4)',
                            'rgba(0, 255, 0, 0.4)',
                            'rgba(0, 0, 255, 0.4)',
                            'rgba(255, 0, 255, 0.4)',
                            'rgba(128, 128, 128, 0.4)',
                            'rgba(255, 165, 0, 0.4)',
                            'rgba(0, 128, 128, 0.4)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(255, 255, 0, 1)',
                            'rgba(0, 255, 0, 1)',
                            'rgba(0, 0, 255, 1)',
                            'rgba(255, 0, 255, 1)',
                            'rgba(128, 128, 128, 1)',
                            'rgba(255, 165, 0, 1)',
                            'rgba(0, 128, 128, 1)'
                        ],
                        borderWidth: 1
                        },
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    /* indexAxis: 'y', */
                    scales: {
                        x: {
                            stacked: true,
                        },
                        y: {
                            stacked: true
                        }
                    }
                }
            });
        <?php endfor; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\patit\OneDrive\Documentos\RepositoriosDelGit\BEASTMEX\beastmex\resources\views/administrador.blade.php ENDPATH**/ ?>