

<?php echo $__env->yieldContent('estilos', ); ?>

<?php $__env->startSection('contenido'); ?>

    <h1>Compras</h1>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('/layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\patit\OneDrive\Documentos\RepositoriosDelGit\BEASTMEX\beastmex\resources\views/compras.blade.php ENDPATH**/ ?>