<?php $__env->startSection('estilos'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/almacen.css')); ?>">
<script src="https://unpkg.com/sweetalert2@9.5.3/dist/sweetalert2.all.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <h1 class="titulo">Almacen</h1>

    <?php if(session()->has('confirmacion')): ?>
    <script>
        const confirmacion = <?php echo json_encode(session('confirmacion'), 15, 512) ?>;
        Swal.fire({
            icon: 'success',
            title: confirmacion,
        });
    </script>
    <?php echo e(session()->forget('confirmacion')); ?>

    <?php endif; ?>

    <?php if(session()->has('fallo')): ?>
    <script>
        const confirmacion = <?php echo json_encode(session('fallo'), 15, 512) ?>;
        Swal.fire({
            icon: 'error',
            title: confirmacion,
        });
    </script>
    <?php echo e(session()->forget('fallo')); ?>

    <?php endif; ?>

    <div class="buscar-imprimir ">
        <div class="col-sm-8 me-3">
            <form method="POST" action="<?php echo e(route('almacen.filtro')); ?>" class="d-flex" role="search">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <input class="form-control me-2" name="Filtro" placeholder="Buscar" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Buscar</button>
            </form>
        </div>
        <div class="col-sm-4 d-grid gap-2">
            <div class="">
                <button id="imprimirPDF" class="btn btn-primary" onclick="imprimirListaProductos()"><i class="bi bi-printer-fill"></i> Imprimir lista de productos</button>
                <a href="<?php echo e(route('almacen.create')); ?>" class="btn btn-primary boton-especial"><i class="bi bi-plus-circle"></i> Agregar producto</a>
            </div>
        </div>
    </div>
    
    <div class="tarjetas mt-5">
        <?php $__currentLoopData = $consultaProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card" style="width: 18rem;">
                <div class="card-img-top align-content-center" style="height: 250px; overflow: hidden;">
                    <img src="<?php echo e(asset($producto->foto)); ?>" alt="imagen-del-producto" style="object-fit: cover; max-height: 100%;">
                </div>
                
                <div class="card-body">
                    <h5 class="card-title bold"><strong><?php echo e($producto->nombre_producto); ?></strong></h5>
                    <div class="row mb-4">
                        <div class="col-sm-12 marca">
                            <strong>Marca: </strong><?php echo e($producto->marca); ?>

                        </div>
                        <div class="col-sm-6 marca card-text">
                            <strong>Precio: </strong><?php echo e($producto->precio_venta); ?>

                        </div>
                        <div class="col-sm-6 marca card-text">
                            <strong>Stock: </strong><?php echo e($producto->cantidad); ?>

                        </div>
                        <div class="col-sm-12 marca card-text">
                            <strong>Numero de serie: </strong><?php echo e($producto->no_serie); ?>

                        </div>
                        <div class="col-sm-12 marca card-text">
                            <strong>Fecha de registro: </strong><?php echo e($producto->fecha_ingreso); ?>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <form action="<?php echo e(route('almacen.edit', $producto->id)); ?>" method="GET">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary"><i class="bi bi-pencil-square"></i> Editar</button>
                            </form>
                        </div>
                        <div class="col-sm-6">
                            <button type="submit" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#confirmarEliminarModal<?php echo e($producto->id); ?>"><i class="bi bi-trash"></i> Eliminar</button>
                        </div>
                    </div>
                </div>
            </div>
        
            
            <div class="modal fade" id="confirmarEliminarModal<?php echo e($producto->id); ?>" tabindex="-1" aria-labelledby="confirmarEliminarModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="confirmarEliminarModalLabel">Confirmar Eliminación</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            ¿Estás seguro de que deseas eliminar este producto?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            <form id="eliminarForm" method="POST" action="<?php echo e(route('almacen.destroy', $producto->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <button type="submit" class="btn btn-danger">Eliminar</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <script>
        function imprimirListaProductos() {
            // Realizar una solicitud AJAX a la ruta de impresión
            fetch("<?php echo e(route('imprimir.lista.productos')); ?>")
                .then(response => response.blob())
                .then(blob => {
                    // Crear un objeto URL del blob y crear un enlace para descargar el PDF
                    var url = window.URL.createObjectURL(blob);
                    var a = document.createElement('a');
                    a.href = url;
                    a.download = 'lista_productos.pdf';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                })
                .catch(error => console.error('Error al imprimir lista de productos:', error));
        }
    </script>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\patit\OneDrive\Documentos\RepositoriosDelGit\BEASTMEX\beastmex\resources\views/almacen/almacen.blade.php ENDPATH**/ ?>