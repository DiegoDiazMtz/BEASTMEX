

<?php $__env->startSection('contenido'); ?>
    <h1>Administrador</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Laravel\BEASTMEX\beastmex\resources\views/administrador.blade.php ENDPATH**/ ?>